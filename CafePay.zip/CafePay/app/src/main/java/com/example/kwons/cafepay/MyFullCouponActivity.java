package com.example.kwons.cafepay;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MyFullCouponActivity extends AppCompatActivity {
    private ListView listView;
    private FullCouponAdapter adapter;
    private List<FullCoupon> myFullCouponList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_full_coupon);

        listView=(ListView)findViewById(R.id.myFullCouponListView);
        myFullCouponList=new ArrayList<FullCoupon>();

        //디비연동전 예시데이터
        //해당 카페의 쿠폰 개수받아서 개수만큼 for문 돌리기
        myFullCouponList.add(new FullCoupon("스타벅스"));
        myFullCouponList.add(new FullCoupon("탐앤탐스"));
        myFullCouponList.add(new FullCoupon("엔젤리너스"));


        adapter=new FullCouponAdapter(getApplicationContext(),myFullCouponList);
        listView.setAdapter(adapter);

    }
}
